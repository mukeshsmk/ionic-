import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { UploadimgPage } from './uploadimg';

@NgModule({
  declarations: [
    UploadimgPage,
  ],
  imports: [
    IonicPageModule.forChild(UploadimgPage),
  ],
  exports: [
    UploadimgPage
  ]
})
export class UploadimgPageModule {}