import { Component } from '@angular/core';
import { NavController,Nav } from 'ionic-angular';


@Component({
    selector: 'page-faqcontact',
    templateUrl: 'faqcontact.html'
})
export class FaqcontactPage {
 
  constructor(public navCtrl: NavController,public nav:Nav) {
      
  }

}
