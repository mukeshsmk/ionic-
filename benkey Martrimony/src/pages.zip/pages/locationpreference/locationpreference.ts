import { Component} from '@angular/core';
import { NavController, Nav } from 'ionic-angular';

@Component({
  selector: 'page-locationpreference',
  templateUrl: 'locationpreference.html'
})
export class LocationpreferencePage {

  constructor(public navCtrl: NavController,public nav: Nav) {
  }
  
}




