import { Component } from '@angular/core';
import { NavController,Nav } from 'ionic-angular';


@Component({
    selector: 'page-faqprofile',
    templateUrl: 'faqprofile.html'
})
export class FaqprofilePage {
 
  constructor(public navCtrl: NavController,public nav:Nav) {
      
  }

}
