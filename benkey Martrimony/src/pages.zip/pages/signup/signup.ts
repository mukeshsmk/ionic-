import { Component } from '@angular/core';
import { NavController, Nav } from 'ionic-angular';
import { Http } from '@angular/http';
import { LoginPage } from '../../pages/login/login';


import { FormGroup, FormBuilder, Validators } from "@angular/forms";

@Component({
  selector: 'page-signup',
  templateUrl: 'signup.html'
})
export class SignupPage {
   
    public gender: any;
    public country: any;
    public religion: any;
    public cast: any;
    public language: any;

    authForm : FormGroup;

  constructor(public navCtrl: NavController, public nav: Nav, private http: Http,private fb: FormBuilder) {
    this.authForm = fb.group({
      'Name': [null, Validators.compose([Validators.required, Validators.minLength(5), Validators.maxLength(20)])],
      'Password': [null, Validators.compose([Validators.required, Validators.minLength(8) ])],
      'Email': [null, Validators.compose([Validators.required, Validators.pattern('^[a-zA-Z0-9._]+[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$')])],
      'Religion':[null,Validators.compose([Validators.required])],
      'Cast':[null,Validators.compose([Validators.required])],
      'Country':[null,Validators.compose([Validators.required])],
      'Gender':[null,Validators.compose([Validators.required])],
      'DOB':[null,Validators.compose([Validators.required])],
      'Mobile': [null, Validators.compose([Validators.required, Validators.minLength(10), Validators.maxLength(10)])],
      'Language': [null, Validators.compose([Validators.required])],
      'Address': [null, Validators.compose([Validators.required])],

    });
  }


  ionViewDidEnter(){
    let DDlist = 'http://68.66.207.110:8020/GetDDList';
    console.log(DDlist);
    this.http.get(DDlist)
    .subscribe(data=>{
     let result = JSON.parse(data["_body"]);
    // console.log(result);
  
     this.country = result.user[0].Country; 
     this.religion = result.user[0].Religion; 
     this.cast = result.user[0].Cast; 
     this.language = result.user[0].Language; 

    // console.log(this.country);
    // console.log(this.religion);
    // console.log(this.caste);
    // console.log(this.language);
     })
    }
  

  gotologin() {
    setTimeout(() => {
      this.nav.setRoot(LoginPage);
    }, 1000);
  }

  signup() {
 
  var myData = {
    Email: this.authForm.value.Email, 
    Password:this.authForm.value.Password,
    Mobile: this.authForm.value.Mobile,
    Name: this.authForm.value.Name,
    Religion: this.authForm.value.Religion,
    Cast:this.authForm.value.Cast,
    Country: this.authForm.value.Country,
    DOB:this.authForm.value.DOB,
    Language: this.authForm.value.Language,
    Gender:this.authForm.value.Gender,
    Address:this.authForm.value.Address,
  
  }
  console.log(myData)
  this.http.post('http://68.66.207.110:8020/createNewUser', myData)
    .subscribe(data => {
    let resp = JSON.parse(data["_body"]);
    console.log(resp)
        if (resp.status == "Success") {
          this.nav.setRoot(LoginPage);
        }
      });
  }
}
