import { Component } from '@angular/core';
import { NavController,Nav } from 'ionic-angular';


@Component({
    selector: 'page-faqsearch',
    templateUrl: 'faqsearch.html'
})
export class FaqsearchPage {
 
  constructor(public navCtrl: NavController,public nav:Nav) {
      
  }

}
