import { Component } from '@angular/core';
import { NavController,Nav } from 'ionic-angular';


@Component({
    selector: 'page-branchlocator',
    templateUrl: 'branchlocator.html'
})
export class BranchlocatorPage {
 
  constructor(public navCtrl: NavController,public nav:Nav) {
  }
  
}
