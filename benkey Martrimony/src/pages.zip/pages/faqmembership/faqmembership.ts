import { Component } from '@angular/core';
import { NavController,Nav } from 'ionic-angular';


@Component({
    selector: 'page-faqmembership',
    templateUrl: 'faqmembership.html'
})
export class FaqmembershipPage {
 
  constructor(public navCtrl: NavController,public nav:Nav) {
      
  }

}
