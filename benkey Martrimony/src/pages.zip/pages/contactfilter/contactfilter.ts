import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
    selector: 'page-contactfilter',
    templateUrl: 'contactfilter.html'
})
export class ContactfilterPage {
 
  constructor(public navCtrl: NavController) {
  }
  
}
