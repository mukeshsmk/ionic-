import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
    selector: 'page-phoneprivacy',
    templateUrl: 'phoneprivacy.html'
})
export class PhoneprivacyPage {
 
  constructor(public navCtrl: NavController) {
  }
  
}
