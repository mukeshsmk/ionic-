import { Component ,ViewChild,ElementRef} from '@angular/core';
import { NavController, Nav } from 'ionic-angular';

@Component({
  selector: 'page-professional',
  templateUrl: 'professional.html'
})
export class ProfessionalPage {
    @ViewChild('myInput') myInput: ElementRef;
  constructor(public navCtrl: NavController,public nav: Nav) {
  }
  
resize() {
    var element = this.myInput['_elementRef'].nativeElement.getElementsByClassName("text-input")[0];
    var scrollHeight = element.scrollHeight;
    element.style.height = scrollHeight + 'px';
    this.myInput['_elementRef'].nativeElement.style.height = (scrollHeight + 16) + 'px';
}
}




