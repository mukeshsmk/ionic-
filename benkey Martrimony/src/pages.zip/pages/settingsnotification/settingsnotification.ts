import { Component } from '@angular/core';
import { NavController, Nav } from 'ionic-angular';


@Component({
  selector: 'page-settingsnotification',
  templateUrl: 'settingsnotification.html'
})
export class SettingsnotificationPage {

  constructor(public navCtrl: NavController,public nav: Nav) {

  }
  
}
