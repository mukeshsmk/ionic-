import { Component } from '@angular/core';
import { NavController, Nav } from 'ionic-angular';

@Component({
  selector: 'page-religious',
  templateUrl: 'religious.html'
})
export class ReligiousPage {

  constructor(public navCtrl: NavController,public nav: Nav) {


}
}
