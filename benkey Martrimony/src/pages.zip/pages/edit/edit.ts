import { Component } from '@angular/core';
import { NavController, Nav } from 'ionic-angular';

import { MembershipPage } from '../../pages/membership/membership';
import { EditprofileownPage } from '../../pages/editprofileown/editprofileown';
import { BasicdetailsPage } from '../../pages/basicdetails/basicdetails';
import { ReligiousPage } from '../../pages/religious/religious';
import { ProfessionalPage } from '../../pages/professional/professional';
import { LocationPage } from '../../pages/location/location';
import { FamilydetailsPage } from '../../pages/familydetails/familydetails';
import { AboutmyfamilyPage } from '../../pages/aboutmyfamily/aboutmyfamily';
import { PartnerbasicdetailsPage } from '../../pages/partnerbasicdetails/partnerbasicdetails';
import { partnerreligiousPage } from '../../pages/partnerreligious/partnerreligious';
import { ProfessionalpreferancePage } from '../../pages/professionalpreferance/professionalpreferance';
import { LocationpreferencePage } from '../../pages/locationpreference/locationpreference';
import { LookingforPage } from '../../pages/lookingfor/lookingfor';

@Component({
  selector: 'page-edit',
  templateUrl: 'edit.html'
})
export class EditPage {

  constructor(public navCtrl: NavController,public nav: Nav) {


}
gotomember(){
  setTimeout(()=>{
    this.nav.push(MembershipPage) ;
}),1000;
}

gotoown(){
  setTimeout(()=>{
    this.nav.push(EditprofileownPage) ;
}),1000;
}

gotobasicdetail(){
  setTimeout(()=>{
    this.nav.push(BasicdetailsPage) ;
}),1000;
}

gotoreligious(){
  setTimeout(()=>{
    this.nav.push(ReligiousPage) ;
}),1000;
}

gotoprofessional(){
  setTimeout(()=>{
    this.nav.push(ProfessionalPage) ;
}),1000;
}

gotolocation(){
  setTimeout(()=>{
    this.nav.push(LocationPage) ;
}),1000;
}


gotofamilydetails(){
  setTimeout(()=>{
    this.nav.push(FamilydetailsPage) ;
}),1000;
}

gotoaboutmyfamily(){
  setTimeout(()=>{
    this.nav.push(AboutmyfamilyPage) ;
}),1000;
}

gotopartnerbasicdetails(){
  setTimeout(()=>{
    this.nav.push(PartnerbasicdetailsPage) ;
}),1000;
}

gotopartnerreligious(){
  setTimeout(()=>{
    this.nav.push(partnerreligiousPage) ;
}),1000;
}

gotoprofessionalpreferance(){
  setTimeout(()=>{
    this.nav.push(ProfessionalpreferancePage) ;
}),1000;
}

gotolocationpreference(){
  setTimeout(()=>{
    this.nav.push(LocationpreferencePage) ;
}),1000;
}

gotolookingfor(){
  setTimeout(()=>{
    this.nav.push(LookingforPage) ;
}),1000;
}


}
