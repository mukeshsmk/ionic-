import { Component } from '@angular/core';
import { NavController, Nav } from 'ionic-angular';

@Component({
  selector: 'page-partnerbasicdetails',
  templateUrl: 'partnerbasicdetails.html'
})
export class PartnerbasicdetailsPage {

  constructor(public navCtrl: NavController,public nav: Nav) {


}
}
