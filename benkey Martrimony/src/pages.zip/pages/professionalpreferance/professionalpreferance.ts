import { Component } from '@angular/core';
import { NavController, Nav } from 'ionic-angular';

@Component({
  selector: 'page-professionalpreferance',
  templateUrl: 'professionalpreferance.html'
})
export class ProfessionalpreferancePage {
   
  constructor(public navCtrl: NavController,public nav: Nav) {
  }
  
}




