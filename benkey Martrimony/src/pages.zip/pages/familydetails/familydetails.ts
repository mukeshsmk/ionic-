import { Component ,ViewChild,ElementRef} from '@angular/core';
import { NavController, Nav } from 'ionic-angular';

@Component({
  selector: 'page-familydetails',
  templateUrl: 'familydetails.html'
})
export class FamilydetailsPage {
   
  constructor(public navCtrl: NavController,public nav: Nav) {
  }
  
}




