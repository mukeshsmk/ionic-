import { Component } from '@angular/core';
import { NavController, Nav } from 'ionic-angular';

@Component({
  selector: 'page-successstories',
  templateUrl: 'successstories.html'
})
export class SuccessstoriesPage {

  constructor(public navCtrl: NavController,public nav: Nav) {


}
}
