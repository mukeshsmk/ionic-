import { Component } from '@angular/core';
import { NavController,Nav } from 'ionic-angular';


@Component({
    selector: 'page-faqprivacy',
    templateUrl: 'faqprivacy.html'
})
export class FaqprivacyPage {
 
  constructor(public navCtrl: NavController,public nav:Nav) {
      
  }

}
