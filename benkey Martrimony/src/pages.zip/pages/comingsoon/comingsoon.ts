import { Component } from '@angular/core';
import { NavController, Nav } from 'ionic-angular';
import { LoginPage } from '../../pages/login/login';
import { LoadingController } from 'ionic-angular';
@Component({
    selector: 'page-comingsoon',
    templateUrl: 'comingsoon.html'
})
export class ComingsoonPage {
 
  constructor(public navCtrl: NavController, public loadingCtrl: LoadingController, public nav: Nav) {
  }
  gotologout() {
    let loading = this.loadingCtrl.create({
      content: 'Loading...'
    });
  
    loading.present();
    setTimeout(() => {
      this.nav.setRoot(LoginPage);
    }, 1000);
    setTimeout(() => {
      loading.dismiss();
    }, 1000);
  }
}
