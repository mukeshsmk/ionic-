import { Component } from '@angular/core';
import { NavController, Nav } from 'ionic-angular';
import { Http } from '@angular/http';
import { AlertController } from 'ionic-angular';
import { LoadingController } from 'ionic-angular';
import { SignupPage } from '../../pages/signup/signup';
import { EditPage } from '../../pages/edit/edit';
@Component({
  selector: 'page-login',
  templateUrl: 'login.html'
})
export class LoginPage {

  user = {};

  constructor(public navCtrl: NavController, public nav: Nav, private http: Http, private alertCtrl: AlertController,public loadingCtrl: LoadingController) {

  }
  gotologin() {
    setTimeout(() => {
      this.nav.setRoot(SignupPage);
    }, 1000);
  }

  login() {
    console.log(this.user)
    var data1 = this.user;
    console.log(data1)
    this.http.post('http://68.66.207.110:8020/authenticate', data1)
      .subscribe(data => {
        let resp = JSON.parse(data["_body"]);
        console.log(resp)
        if (resp.status == "Success") {
          let loading = this.loadingCtrl.create({
            content: 'Please wait...'
          });
        
          loading.present();
        
          setTimeout(() => {
            this.nav.setRoot(EditPage);
            loading.dismiss();
          }, 3000);
        
         
        }
        else {
            let alert = this.alertCtrl.create({
              title: "Login Failed",
              subTitle: resp.message,
              buttons: ['Ok']
            });
            alert.present();
          }
        
        });
  }
}
